# User Management API (.NET 6)

## Features
- CRUD operations for users
- Validation with data annotations
- Logging middleware
- Swagger UI

## Technologies
- .NET 6
- ASP.NET Core Web API

## Run Locally
```bash
dotnet restore
dotnet run
```

## Copilot Use
This project was enhanced and debugged with GitHub Copilot suggestions, especially during model validation and middleware design.