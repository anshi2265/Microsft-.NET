using UserManagementApi.Models;
using System.Collections.Generic;
using System.Linq;

namespace UserManagementApi.Services
{
    public class UserService
    {
        private readonly List<User> _users = new();

        public List<User> GetAll() => _users;

        public User Get(int id) => _users.FirstOrDefault(u => u.Id == id);

        public void Add(User user)
        {
            user.Id = _users.Count > 0 ? _users.Max(u => u.Id) + 1 : 1;
            _users.Add(user);
        }

        public bool Update(int id, User updatedUser)
        {
            var user = Get(id);
            if (user == null) return false;
            user.Username = updatedUser.Username;
            user.Email = updatedUser.Email;
            user.Password = updatedUser.Password;
            return true;
        }

        public bool Delete(int id)
        {
            var user = Get(id);
            if (user == null) return false;
            _users.Remove(user);
            return true;
        }
    }
}